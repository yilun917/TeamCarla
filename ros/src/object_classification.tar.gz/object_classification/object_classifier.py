#!/usr/bin/env python
import rospy
import tensorflow as tf
import cv2
import random
import numpy as np
import numpy as np
import tensorflow as tf
import os
import sys
import yaml
#from utils import label_map_util
import label_map_util
#import visualization_utils as vis_util

import time
from scipy.stats import norm
from styx_msgs.msg import TrafficLight
from styx_msgs.msg import ObjectType

class OBClassifier(object):
    def __init__(self):
        # Frozen inference graph files. NOTE: change the path to where you saved the models.
        config_string = rospy.get_param("/traffic_light_config")
        self.config = yaml.safe_load(config_string)

        self.detection_graph = None
        self.num_detections = None
        self.boxes = None
        self.scores = None
        self.classes = None

        self.label_map = None
        self.category_index = None
        self.NUM_CLASSES = 90
        self.MIN_SCORE_THRESHOLD = 0.40

        # Grab path to current working directory
        CWD_PATH = os.getcwd()
        self.is_real = self.config['is_site']

        if self.is_real:
            MODEL_NAME = 'faster_rcnn_v2_coco_site_v1.3'
        else:
            MODEL_NAME = 'faster_rcnn_v2_coco_sim_v1.3'

        PATH_TO_CKPT = os.path.join(CWD_PATH, 'object_classification', MODEL_NAME,'frozen_inference_graph.pb')
        PATH_TO_LABELS = os.path.join(CWD_PATH,'object_classification', MODEL_NAME,'mscoco_label_map.pbtxt')

        # Load the label map
        self.label_map      = label_map_util.load_labelmap(PATH_TO_LABELS)
        categories          = label_map_util.convert_label_map_to_categories(self.label_map, max_num_classes=self.NUM_CLASSES, use_display_name=True)
        self.category_index = label_map_util.create_category_index(categories)

        # Load the Tensorflow model into memory.
        self.detection_graph = tf.Graph()
        with self.detection_graph.as_default():
            od_graph_def = tf.GraphDef()
            with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
                serialized_graph = fid.read()
                od_graph_def.ParseFromString(serialized_graph)
                tf.import_graph_def(od_graph_def, name='')

            self.sess = tf.Session(graph=self.detection_graph)
        
        sample = cv2.imread(CWD_PATH + '/sample_load.jpg')
        
        image_tensor = self.detection_graph.get_tensor_by_name('image_tensor:0')
        detection_boxes = self.detection_graph.get_tensor_by_name('detection_boxes:0')
        detection_scores = self.detection_graph.get_tensor_by_name('detection_scores:0')
        detection_classes = self.detection_graph.get_tensor_by_name('detection_classes:0')
        num_detections = self.detection_graph.get_tensor_by_name('num_detections:0')

        image_expanded = np.expand_dims(sample, axis=0)
        
        #(self.boxes, self.scores, self.classes) = self.sess.run([detection_boxes, detection_scores, detection_classes],\
         #   feed_dict={image_tensor: image_expanded})

        rospy.loginfo("  ")
        rospy.loginfo("  ")
        rospy.loginfo("============ Classifier loaded! ============")

    def get_ob_classification(self, image):
        
                #TODO implement light color prediction

        start_time = time.time()
       
        # Define input and output tensors (i.e. data) for the object detection classifier
        # Input tensor is the image
        image_tensor = self.detection_graph.get_tensor_by_name('image_tensor:0')

        # Output tensors are the detection boxes, scores, and classes
        detection_boxes = self.detection_graph.get_tensor_by_name('detection_boxes:0')
        detection_scores = self.detection_graph.get_tensor_by_name('detection_scores:0')
        detection_classes = self.detection_graph.get_tensor_by_name('detection_classes:0')
        num_detections = self.detection_graph.get_tensor_by_name('num_detections:0')

        # Expand image
        image_expanded = np.expand_dims(image, axis=0)
        
        # Perform the actual detection by running the model with the image as input
        (self.boxes, self.scores, self.classes) = self.sess.run([detection_boxes, detection_scores, detection_classes],\
            feed_dict={image_tensor: image_expanded})
        
        end_time = time.time()


        if self.scores[0][0] < self.MIN_SCORE_THRESHOLD:
            object_type = ObjectType.UNKNOWN
            caption = 'UNKNOWN '
        elif self.classes[0][0] == 1:
            rospy.loginfo("object_classifier::PEDESTRIAN found")
            object_type = ObjectType.PEDESTRIAN
            caption = 'pedestrian: ' + str(self.scores[0][0] * 100)[:5] + '%'
        elif self.classes[0][0] == 2:
            rospy.loginfo("object_classifier::BICYCLE found")
            object_type = ObjectType.BICYCLE
            caption = 'bicycle: ' + str(self.scores[0][0] * 100)[:5] + '%'
        elif self.classes[0][0] == 3:
            rospy.loginfo("object_classifier::VEHICLE found")
            object_type = ObjectType.VEHICLE
            caption = 'vehicle ' + str(self.scores[0][0] * 100)[:5] + '%'
        elif self.classes[0][0] == 10:
            rospy.loginfo("object_classifier::TRAFFIC_LIGHT found")
            object_type = ObjectType.TRAFFIC_LIGHT
            caption = 'traffic_lights ' + str(self.scores[0][0] * 100)[:5] + '%'
        else:
            rospy.loginfo("object_classifier::NON OBJECT found")
            object_type = ObjectType.UNKNOWN
            caption = 'UNKNOWN '

        return object_type
